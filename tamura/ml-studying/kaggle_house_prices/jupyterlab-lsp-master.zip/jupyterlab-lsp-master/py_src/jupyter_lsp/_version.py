""" single source of truth for jupyter_lsp version
"""
__version__ = "0.6.0b0"
