async def dummy_listener(scope, message, languages, manager):
    pass
