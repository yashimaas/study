# a helper script for launching languageserver
languageserver::run(debug = TRUE)
