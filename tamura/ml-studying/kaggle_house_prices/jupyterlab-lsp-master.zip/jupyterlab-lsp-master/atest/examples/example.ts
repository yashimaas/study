function inc(x: number) {
    return x + 1;
}

let y = inc(0) + 'a';
y / 2;