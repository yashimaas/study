import '@krassowski/jupyterlab-lsp';
import 'lsp-ws-connection';
