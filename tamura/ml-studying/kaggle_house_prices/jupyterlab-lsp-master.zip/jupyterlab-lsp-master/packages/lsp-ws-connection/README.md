# lsp-ws-connection

> This is a fork of [lsp-editor-adapter](https://github.com/wylieconlon/lsp-editor-adapter), with
> a number of modifications made to make it more easily integrated into [jupyterlab-lsp](https://github.com/krassowski/jupyterlab-lsp)

## Installation

> TBD

## Developing

This library is built and tested as part of the [`jupyterlab-lsp` monorepo](https://github.com/krassowski/jupyterlab-lsp).
