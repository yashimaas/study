---
name: Request a Future Roadmap item
about: Help us build future features
---

<!--
Welcome! Before creating a new issue:
* Search for relevant issues
* Look at ROADMAP.md to make sure we don't already want the same thing
* Follow the issue reporting guidelines:
https://jupyterlab.readthedocs.io/en/latest/getting_started/issue.html
-->

## Elevator Pitch

<!-- In no more than three sentences, what would you like to see implemented? -->

## Motivation

<!-- Why do you want this feature? -->

## Design Ideas

<!-- Share any kind of design ideas (e.g. ASCII art, links, screenshots) that might help us understand -->
